# Personal Learning Tutor GPT - Prompt Templates

This document provides a collection of prompt templates for effectively using the Personal Learning Tutor GPT. These templates are designed to help you get the most out of your interactions with the tutoring system.

## Table of Contents
1. [Initial Setup](#initial-setup)
2. [Learning New Concepts](#learning-new-concepts)
3. [Working with Materials](#working-with-materials)
4. [Assessment and Practice](#assessment-and-practice)
5. [Customizing Your Experience](#customizing-your-experience)
6. [Advanced Usage](#advanced-usage)

## Initial Setup

### Setting Up Your Learning Profile

```
Act as a patient tutor for a [beginner/intermediate/advanced] learner. I prefer a [friendly/professional/enthusiastic/patient/socratic] tone. I learn best through [visual explanations/verbal discussions/reading and writing/hands-on activities]. Please present information in [continuous text/bullet points/step-by-step/question-answer/conversational] format.
```

### Starting a Learning Session

```
I want to learn about [topic]. My goal is to [specific learning objective]. I have [no prior knowledge/some familiarity/extensive experience] with this subject. Please help me create a structured learning plan.
```

### Specifying Learning Goals

```
I need to [understand/master/review] [topic] for [purpose/context]. My specific goals are:
1. [Goal 1]
2. [Goal 2]
3. [Goal 3]
Please help me achieve these goals with a personalized learning approach.
```

## Learning New Concepts

### Requesting Basic Explanations

```
Please explain [concept] in simple terms. I'm a [beginner/intermediate/advanced] learner who prefers [learning style] explanations.
```

### Requesting Detailed Explanations

```
I need an in-depth explanation of [concept]. Please include:
- Key principles and components
- How it relates to [related concept]
- Real-world applications
- Common misconceptions
```

### Asking Follow-up Questions

```
Regarding [concept] that you just explained:
- Could you clarify [specific aspect]?
- How does this compare to [related concept]?
- What are the limitations or exceptions?
```

### Requesting Examples

```
Please provide [number] examples of [concept] in action. I would prefer examples that are [practical/theoretical/simple/complex/real-world] in nature.
```

### Requesting Analogies

```
Could you explain [concept] using an analogy or metaphor that would make it easier to understand? I'm familiar with [domain/interest] if that helps create a relevant comparison.
```

## Working with Materials

### Uploading Learning Materials

```
I have the following material about [topic]:

[Paste content here]

Please process this information and help me understand the key concepts.
```

### Creating Study Notes

```
Based on the [textbook/article/notes] I shared, please create concise study notes that highlight:
- Main concepts and definitions
- Key relationships and processes
- Important formulas or principles
- Areas I should focus on
```

### Summarizing Complex Materials

```
I need help understanding this complex material about [topic]. Please summarize the main points in a way that's easy to understand for someone with my background.
```

### Comparing Different Sources

```
I have information from multiple sources about [topic]:

Source 1: [content]
Source 2: [content]

Please compare these perspectives and help me understand the key similarities and differences.
```

## Assessment and Practice

### Requesting Practice Questions

```
Please create [number] [multiple-choice/open-ended/true-false/fill-in-the-blank] questions about [topic] at a [beginner/intermediate/advanced] level to test my understanding.
```

### Creating a Quiz

```
I'd like a comprehensive quiz on [topic] covering [specific aspects]. Please include a mix of question types and provide answers so I can check my understanding afterward.
```

### Requesting Problem-Solving Exercises

```
Please provide [number] practice problems on [topic] that will help me apply the concepts I've learned. Start with simpler problems and gradually increase the difficulty.
```

### Requesting Feedback on Answers

```
Here's my answer to the question about [topic]:

[Your answer]

Please evaluate my response and provide constructive feedback on what I did well and where I can improve.
```

## Customizing Your Experience

### Adjusting Difficulty Level

```
I'm finding the current explanations [too simple/too complex]. Please [increase/decrease] the difficulty level and [add more technical details/simplify the terminology].
```

### Changing Teaching Style

```
I'd like to try a different teaching approach. Instead of the current method, could you use a [socratic/direct/guided discovery/exploratory] approach for our next topic?
```

### Adjusting Content Format

```
I'm finding it difficult to process information in the current format. Could you present the information as [bullet points/step-by-step instructions/a conversational dialogue/question and answer pairs] instead?
```

### Requesting More or Fewer Examples

```
I would benefit from [more/fewer] examples when explaining concepts. Please [increase/decrease] the number of examples you provide in your explanations.
```

## Advanced Usage

### Creating a Custom Learning Path

```
I want to master [broad topic] over the next [timeframe]. My current knowledge level is [beginner/intermediate/advanced]. Please create a structured learning path that:
- Breaks the subject into logical modules
- Sequences topics in an optimal learning order
- Includes checkpoints to assess my progress
- Recommends resources for each stage
```

### Interdisciplinary Learning

```
I'm interested in understanding how [topic A] relates to [topic B]. Please help me explore the connections between these fields and how concepts from one area apply to the other.
```

### Preparing for Assessment

```
I have an [exam/presentation/interview] on [topic] in [timeframe]. Please help me prepare by:
- Identifying the most important concepts to review
- Creating practice questions similar to what I might encounter
- Suggesting effective study strategies
- Helping me identify and address knowledge gaps
```

### Deep Dive into Specific Concept

```
I want to do a deep dive into [specific concept]. Please provide:
- A comprehensive explanation of the concept
- Historical development and key contributors
- Current state of research or understanding
- Practical applications and implications
- Controversies or unresolved questions
- Related concepts I should also understand
```

---

These templates provide a starting point for effective interaction with the Personal Learning Tutor GPT. Feel free to modify them to suit your specific needs and learning preferences. Remember that you can combine elements from different templates to create the perfect prompt for your situation.

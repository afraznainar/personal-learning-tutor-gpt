"""
Personal Learning Tutor GPT - Customization Features

This module implements the customization features for the Personal Learning Tutor GPT system,
extending the core functionality with additional options for personalization.
"""

import json
import os
from enum import Enum
from typing import Dict, List, Optional, Any

# Import core functionality
from core_functionality import (
    PersonalLearningTutorGPT,
    TeachingStyle,
    ToneStyle,
    DifficultyLevel,
    QuestionType
)

# ======================================================================
# Extended Customization Options
# ======================================================================

class LearningStyle(Enum):
    VISUAL = "visual"
    AUDITORY = "auditory"
    READING_WRITING = "reading_writing"
    KINESTHETIC = "kinesthetic"

class FeedbackStyle(Enum):
    DETAILED = "detailed"
    CONCISE = "concise"
    POSITIVE = "positive"
    CONSTRUCTIVE = "constructive"
    SOCRATIC = "socratic"

class PacePreference(Enum):
    SLOW = "slow"
    MODERATE = "moderate"
    FAST = "fast"
    ADAPTIVE = "adaptive"

class ContentFormat(Enum):
    TEXT = "text"
    BULLET_POINTS = "bullet_points"
    STEP_BY_STEP = "step_by_step"
    QUESTION_ANSWER = "question_answer"
    CONVERSATIONAL = "conversational"

# ======================================================================
# User Preference Profile
# ======================================================================

class UserPreferenceProfile:
    """
    Manages user preferences for the learning experience.
    """
    
    def __init__(self, user_id: str):
        """
        Initialize a user preference profile.
        
        Args:
            user_id: Unique identifier for the user
        """
        self.user_id = user_id
        self.preferences = {
            "teaching_style": TeachingStyle.DIRECT.value,
            "tone_style": ToneStyle.FRIENDLY.value,
            "difficulty_level": DifficultyLevel.INTERMEDIATE.value,
            "learning_style": LearningStyle.READING_WRITING.value,
            "feedback_style": FeedbackStyle.CONSTRUCTIVE.value,
            "pace_preference": PacePreference.MODERATE.value,
            "content_format": ContentFormat.TEXT.value,
            "verbosity": 0.7,  # 0.0 to 1.0, higher means more detailed explanations
            "formality": 0.5,  # 0.0 to 1.0, higher means more formal language
            "humor": 0.3,      # 0.0 to 1.0, higher means more humor
            "technical_level": 0.5,  # 0.0 to 1.0, higher means more technical language
            "example_frequency": 0.5,  # 0.0 to 1.0, higher means more examples
            "visual_aids": True,  # Whether to include visual aids when available
            "session_memory": True,  # Whether to remember previous interactions in the session
            "custom_settings": {}  # Additional custom settings
        }
        self.profile_path = None
    
    def update_preferences(self, preferences: Dict) -> None:
        """
        Update user preferences.
        
        Args:
            preferences: Dictionary of preference settings to update
        """
        for key, value in preferences.items():
            if key in self.preferences:
                self.preferences[key] = value
    
    def get_preferences(self) -> Dict:
        """
        Get the current user preferences.
        
        Returns:
            preferences: Dictionary of current preference settings
        """
        return self.preferences.copy()
    
    def save_profile(self, directory: str) -> str:
        """
        Save the user preference profile to a file.
        
        Args:
            directory: Directory to save the profile
            
        Returns:
            file_path: Path to the saved profile file
        """
        os.makedirs(directory, exist_ok=True)
        file_path = os.path.join(directory, f"user_profile_{self.user_id}.json")
        
        with open(file_path, 'w') as f:
            json.dump(self.preferences, f, indent=2)
        
        self.profile_path = file_path
        return file_path
    
    def load_profile(self, file_path: str) -> bool:
        """
        Load a user preference profile from a file.
        
        Args:
            file_path: Path to the profile file
            
        Returns:
            success: Whether the profile was successfully loaded
        """
        if not os.path.exists(file_path):
            return False
        
        try:
            with open(file_path, 'r') as f:
                preferences = json.load(f)
            
            self.update_preferences(preferences)
            self.profile_path = file_path
            return True
        except Exception as e:
            print(f"Error loading profile: {e}")
            return False


# ======================================================================
# Content Adaptation System
# ======================================================================

class ContentAdaptationSystem:
    """
    Adapts content based on user preferences and learning styles.
    """
    
    def __init__(self):
        """Initialize the Content Adaptation System."""
        self.adaptation_strategies = {
            LearningStyle.VISUAL.value: self._adapt_for_visual_learner,
            LearningStyle.AUDITORY.value: self._adapt_for_auditory_learner,
            LearningStyle.READING_WRITING.value: self._adapt_for_reading_writing_learner,
            LearningStyle.KINESTHETIC.value: self._adapt_for_kinesthetic_learner
        }
        
        self.format_strategies = {
            ContentFormat.TEXT.value: self._format_as_text,
            ContentFormat.BULLET_POINTS.value: self._format_as_bullet_points,
            ContentFormat.STEP_BY_STEP.value: self._format_as_step_by_step,
            ContentFormat.QUESTION_ANSWER.value: self._format_as_question_answer,
            ContentFormat.CONVERSATIONAL.value: self._format_as_conversational
        }
    
    def adapt_content(self, content: Dict, preferences: Dict) -> Dict:
        """
        Adapt content based on user preferences.
        
        Args:
            content: The content to adapt
            preferences: User preferences
            
        Returns:
            adapted_content: The adapted content
        """
        adapted_content = content.copy()
        
        # Apply learning style adaptation if specified
        if "learning_style" in preferences:
            learning_style = preferences["learning_style"]
            if learning_style in self.adaptation_strategies:
                adapted_content = self.adaptation_strategies[learning_style](adapted_content, preferences)
        
        # Apply content format if specified
        if "content_format" in preferences:
            content_format = preferences["content_format"]
            if content_format in self.format_strategies:
                adapted_content = self.format_strategies[content_format](adapted_content, preferences)
        
        # Adjust verbosity if specified
        if "verbosity" in preferences:
            adapted_content = self._adjust_verbosity(adapted_content, preferences["verbosity"])
        
        # Adjust example frequency if specified
        if "example_frequency" in preferences:
            adapted_content = self._adjust_example_frequency(adapted_content, preferences["example_frequency"])
        
        return adapted_content
    
    def _adapt_for_visual_learner(self, content: Dict, preferences: Dict) -> Dict:
        """Adapt content for visual learners."""
        adapted_content = content.copy()
        
        # Add visual cues and imagery suggestions
        if "explanation" in adapted_content:
            explanation = adapted_content["explanation"]
            adapted_content["explanation"] = (
                explanation + 
                "\n\n[Visual representation: This concept can be visualized as a diagram showing the relationships between key elements.]"
            )
        
        # Add suggestions for diagrams, charts, or mind maps
        if "summary" in adapted_content:
            adapted_content["summary"] += "\n\nTry creating a mind map of these concepts to visualize the connections."
        
        # Add visual metaphors
        if "introduction" in adapted_content:
            adapted_content["introduction"] += " Think of this concept as a visual puzzle where each piece connects to form a complete picture."
        
        return adapted_content
    
    def _adapt_for_auditory_learner(self, content: Dict, preferences: Dict) -> Dict:
        """Adapt content for auditory learners."""
        adapted_content = content.copy()
        
        # Add suggestions for verbal repetition
        if "summary" in adapted_content:
            adapted_content["summary"] += "\n\nTry reading these key points aloud to reinforce your understanding."
        
        # Add discussion prompts
        if "next_steps" in adapted_content:
            adapted_content["next_steps"] += " Consider discussing these concepts with someone to verbalize your understanding."
        
        # Add rhythmic or mnemonic devices
        if "explanation" in adapted_content:
            adapted_content["explanation"] += "\n\n[Auditory tip: Create a simple mnemonic or rhythm to remember the key sequence of steps.]"
        
        return adapted_content
    
    def _adapt_for_reading_writing_learner(self, content: Dict, preferences: Dict) -> Dict:
        """Adapt content for reading/writing learners."""
        adapted_content = content.copy()
        
        # Add text-based explanations and definitions
        if "explanation" in adapted_content:
            explanation = adapted_content["explanation"]
            if not explanation.startswith("Definition:"):
                adapted_content["explanation"] = "Definition: " + explanation
        
        # Add note-taking suggestions
        if "summary" in adapted_content:
            adapted_content["summary"] += "\n\nTry summarizing these points in your own words to reinforce your understanding."
        
        # Add references to textual resources
        if "next_steps" in adapted_content:
            adapted_content["next_steps"] += " You might find it helpful to write out the key concepts and their relationships."
        
        return adapted_content
    
    def _adapt_for_kinesthetic_learner(self, content: Dict, preferences: Dict) -> Dict:
        """Adapt content for kinesthetic learners."""
        adapted_content = content.copy()
        
        # Add hands-on activity suggestions
        if "next_steps" in adapted_content:
            adapted_content["next_steps"] += " Try applying this concept through a hands-on activity or real-world problem."
        
        # Add interactive elements
        if "explanation" in adapted_content:
            adapted_content["explanation"] += "\n\n[Activity suggestion: Create a physical model or simulation to represent this concept.]"
        
        # Add movement-based learning tips
        if "summary" in adapted_content:
            adapted_content["summary"] += "\n\nConsider walking around while reviewing these concepts to engage your kinesthetic learning style."
        
        return adapted_content
    
    def _format_as_text(self, content: Dict, preferences: Dict) -> Dict:
        """Format content as continuous text."""
        # This is the default format, so no changes needed
        return content
    
    def _format_as_bullet_points(self, content: Dict, preferences: Dict) -> Dict:
        """Format content as bullet points."""
        formatted_content = content.copy()
        
        # Convert explanation to bullet points if it exists
        if "explanation" in formatted_content:
            explanation = formatted_content["explanation"]
            sentences = [s.strip() for s in explanation.split('.') if s.strip()]
            bullet_points = "\n".join([f"• {sentence}." for sentence in sentences])
            formatted_content["explanation"] = bullet_points
        
        # Convert summary to bullet points if it exists
        if "summary" in formatted_content:
            summary = formatted_content["summary"]
            sentences = [s.strip() for s in summary.split('.') if s.strip()]
            bullet_points = "\n".join([f"• {sentence}." for sentence in sentences])
            formatted_content["summary"] = bullet_points
        
        return formatted_content
    
    def _format_as_step_by_step(self, content: Dict, preferences: Dict) -> Dict:
        """Format content as step-by-step instructions."""
        formatted_content = content.copy()
        
        # Convert explanation to numbered steps if it exists
        if "explanation" in formatted_content:
            explanation = formatted_content["explanation"]
            sentences = [s.strip() for s in explanation.split('.') if s.strip()]
            steps = "\n".join([f"{i+1}. {sentence}." for i, sentence in enumerate(sentences)])
            formatted_content["explanation"] = steps
        
        # Add a step-by-step framework
        if "introduction" in formatted_content:
            formatted_content["introduction"] += " Let's break this down into clear steps."
        
        return formatted_content
    
    def _format_as_question_answer(self, content: Dict, preferences: Dict) -> Dict:
        """Format content as questions and answers."""
        formatted_content = content.copy()
        
        # Convert explanation to Q&A format if it exists
        if "explanation" in formatted_content:
            explanation = formatted_content["explanation"]
            title = formatted_content.get("title", "This concept")
            
            # Create Q&A pairs based on content
            qa_format = f"Q: What is {title}?\nA: {explanation}\n\n"
            
            # Add additional Q&A pairs if possible
            if "summary" in formatted_content:
                qa_format += f"Q: What are the key points about {title}?\nA: {formatted_content['summary']}\n\n"
            
            if "next_steps" in formatted_content:
                qa_format += f"Q: How can I apply what I've learned about {title}?\nA: {formatted_content['next_steps']}"
            
            formatted_content["explanation"] = qa_format
            
            # Remove redundant sections now covered in Q&A
            if "summary" in formatted_content:
                del formatted_content["summary"]
            
            if "next_steps" in formatted_content:
                del formatted_content["next_steps"]
        
        return formatted_content
    
    def _format_as_conversational(self, content: Dict, preferences: Dict) -> Dict:
        """Format content as a conversational dialogue."""
        formatted_content = content.copy()
        
        # Convert to conversational format
        if "explanation" in formatted_content:
            explanation = formatted_content["explanation"]
            title = formatted_content.get("title", "this concept")
            
            # Create a conversational dialogue
            conversation = f"Let's chat about {title}. "
            conversation += f"The key thing to understand is {explanation} "
            
            if "summary" in formatted_content:
                conversation += f"To sum it up, {formatted_content['summary']} "
            
            if "next_steps" in formatted_content:
                conversation += f"Moving forward, I'd suggest {formatted_content['next_steps']}"
            
            formatted_content["explanation"] = conversation
            
            # Remove redundant sections now covered in conversation
            if "summary" in formatted_content:
                del formatted_content["summary"]
            
            if "next_steps" in formatted_content:
                del formatted_content["next_steps"]
        
        return formatted_content
    
    def _adjust_verbosity(self, content: Dict, verbosity: float) -> Dict:
        """Adjust content verbosity based on preference."""
        adjusted_content = content.copy()
        
        # For low verbosity, make content more concise
        if verbosity < 0.4:
            if "explanation" in adjusted_content:
                explanation = adjusted_content["explanation"]
                sentences = [s.strip() for s in explanation.split('.') if s.strip()]
                # Keep only about half the sentences
                concise_explanation = '. '.join(sentences[:max(2, len(sentences) // 2)]) + '.'
                adjusted_content["explanation"] = concise_explanation
            
            # Remove optional sections for very low verbosity
            if verbosity < 0.2:
                if "introduction" in adjusted_content:
                    del adjusted_content["introduction"]
                if "summary" in adjusted_content:
                    del adjusted_content["summary"]
        
        # For high verbosity, add more detail
        elif verbosity > 0.7:
            if "explanation" in adjusted_content:
                explanation = adjusted_content["explanation"]
                adjusted_content["explanation"] = explanation + "\n\nTo elaborate further, it's important to understand the nuances and context of this concept. Consider how it relates to other ideas and its practical applications in various scenarios."
            
            # Add additional sections for very high verbosity
            if verbosity > 0.9 and "next_steps" in adjusted_content:
                adjusted_content["next_steps"] += "\n\nFor a deeper understanding, you might want to explore related concepts and consider different perspectives on this topic."
        
        return adjusted_content
    
    def _adjust_example_frequency(self, content: Dict, example_frequency: float) -> Dict:
        """Adjust the frequency of examples in content."""
        adjusted_content = content.copy()
        
        # For low example frequency, remove or reduce examples
        if example_frequency < 0.3:
            # Remove example sections if they exist
            if "examples" in adjusted_content:
                del adjusted_content["examples"]
        
        # For high example frequency, add more examples
        elif example_frequency > 0.7:
            # Add example placeholder - in a real system, this would generate actual examples
            if "explanation" in adjusted_content:
                adjusted_content["explanation"] += "\n\nHere are some examples to illustrate this concept:\n1. Example one\n2. Example two\n3. Example three"
        
        return adjusted_content


# ======================================================================
# Template System
# ======================================================================

class TemplateSystem:
    """
    Manages templates for different types of educational content and interactions.
    """
    
    def __init__(self):
        """Initialize the Template System."""
        self.templates = {
            "explanation": {
                "default": {
                    "title": "{concept}",
                    "introduction": "Let's explore {concept}.",
                    "explanation": "{content}",
                    "summary": "To summarize, {summary}",
                    "next_steps": "Now that you understand {concept}, you can {next_steps}"
                },
                "beginner": {
                    "title": "Introduction to {concept}",
                    "introduction": "Let's start learning about {concept}. This is a beginner-friendly explanation.",
                    "explanation": "{content}",
                    "summary": "In simple terms, {summary}",
                    "next_steps": "To continue learning about {concept}, you can {next_steps}"
                },
                "advanced": {
                    "title": "Advanced {concept}",
                    "introduction": "Let's delve deeper into {concept}.",
                    "explanation": "{content}",
                    "summary": "To summarize these advanced concepts, {summary}",
                    "next_steps": "To master {concept}, you should {next_steps}"
                }
            },
            "question": {
                "multiple_choice": {
                    "question_text": "{question}",
                    "options": "{options}",
                    "hint": "Hint: {hint}"
                },
                "open_ended": {
                    "question_text": "{question}",
                    "prompt": "Consider the following aspects in your answer: {aspects}"
                }
            },
            "feedback": {
                "positive": {
                    "message": "Great job! {feedback}",
                    "encouragement": "Keep up the good work!"
                },
                "constructive": {
                    "message": "Let's review this. {feedback}",
                    "encouragement": "Don't worry, learning is a process. Let's try again."
                }
            },
            "session": {
                "welcome": {
                    "message": "Welcome to your learning session on {topic}!",
                    "goals": "In this session, we'll focus on: {goals}",
                    "structure": "We'll cover: {structure}"
                },
                "summary": {
                    "message": "Let's summarize what we've covered in this session.",
                    "key_points": "Key points: {key_points}",
                    "next_session": "In our next session, we'll explore {next_topic}"
                }
            }
        }
        self.custom_templates = {}
    
    def get_template(self, template_type: str, template_name: str = "default") -> Dict:
        """
        Get a template by type and name.
        
        Args:
            template_type: Type of template (e.g., 'explanation', 'question')
            template_name: Name of the specific template (e.g., 'default', 'beginner')
            
        Returns:
            template: The requested template
        """
        if template_type in self.templates and template_name in self.templates[template_type]:
            return self.templates[template_type][template_name].copy()
        elif template_type in self.templates:
            # Return default template for this type
            return self.templates[template_type]["default"].copy()
        else:
            # Return empty template if not found
            return {}
    
    def add_custom_template(self, user_id: str, template_type: str, template_name: str, template: Dict) -> None:
        """
        Add a custom template for a user.
        
        Args:
            user_id: Unique identifier for the user
            template_type: Type of template
            template_name: Name for the custom template
            template: The template content
        """
        if user_id not in self.custom_templates:
            self.custom_templates[user_id] = {}
        
        if template_type not in self.custom_templates[user_id]:
            self.custom_templates[user_id][template_type] = {}
        
        self.custom_templates[user_id][template_type][template_name] = template
    
    def get_custom_template(self, user_id: str, template_type: str, template_name: str) -> Optional[Dict]:
        """
        Get a custom template for a user.
        
        Args:
            user_id: Unique identifier for the user
            template_type: Type of template
            template_name: Name of the custom template
            
        Returns:
            template: The custom template, or None if not found
        """
        if (user_id in self.custom_templates and 
            template_type in self.custom_templates[user_id] and 
            template_name in self.custom_templates[user_id][template_type]):
            return self.custom_templates[user_id][template_type][template_name].copy()
        else:
            return None
    
    def apply_template(self, template: Dict, values: Dict) -> Dict:
        """
        Apply values to a template.
        
        Args:
            template: The template to fill
            values: Values to insert into the template
            
        Returns:
            filled_template: The template with values inserted
        """
        filled_template = {}
        
        for key, value in template.items():
            if isinstance(value, str):
                # Replace placeholders in strings
                filled_value = value
                for placeholder, replacement in values.items():
                    placeholder_tag = "{" + placeholder + "}"
                    if placeholder_tag in filled_value:
                        filled_value = filled_value.replace(placeholder_tag, str(replacement))
                filled_template[key] = filled_value
            else:
                # Copy non-string values as is
                filled_template[key] = value
        
        return filled_template


# ======================================================================
# Enhanced Personal Learning Tutor GPT
# ======================================================================

class EnhancedPersonalLearningTutorGPT(PersonalLearningTutorGPT):
    """
    Enhanced version of the Personal Learning Tutor GPT with additional customization features.
    """
    
    def __init__(self, base_knowledge_path: Optional[str] = None):
        """
        Initialize the Enhanced Personal Learning Tutor GPT.
        
        Args:
            base_knowledge_path: Path to the base knowledge directory (optional)
        """
        super().__init__(base_knowledge_path)
        
        # Initialize additional components
        self.user_profiles = {}
        self.content_adaptation_system = ContentAdaptationSystem()
        self.template_system = TemplateSystem()
    
    def create_user_profile(self, user_id: str, initial_preferences: Dict = None) -> UserPreferenceProfile:
        """
        Create a new user preference profile.
        
        Args:
            user_id: Unique identifier for the user
            initial_preferences: Initial preference settings (optional)
            
        Returns:
            profile: The created user profile
        """
        profile = UserPreferenceProfile(user_id)
        
        if initial_preferences:
            profile.update_preferences(initial_preferences)
        
        self.user_profiles[user_id] = profile
        return profile
    
    def get_user_profile(self, user_id: str) -> Optional[UserPreferenceProfile]:
        """
        Get a user's preference profile.
        
        Args:
            user_id: Unique identifier for the user
            
        Returns:
            profile: The user's preference profile, or None if not found
        """
        return self.user_profiles.get(user_id)
    
    def update_user_preferences(self, user_id: str, preferences: Dict) -> bool:
        """
        Update a user's preferences.
        
        Args:
            user_id: Unique identifier for the user
            preferences: Dictionary of preference settings to update
            
        Returns:
            success: Whether the preferences were successfully updated
        """
        if user_id not in self.user_profiles:
            self.create_user_profile(user_id)
        
        self.user_profiles[user_id].update_preferences(preferences)
        
        # Update the interaction interface configuration
        config = {}
        for key in ["teaching_style", "tone_style", "difficulty_level", "verbosity", "formality", "humor"]:
            if key in preferences:
                config[key] = preferences[key]
        
        if config:
            self.configure(config)
        
        return True
    
    def process_input_with_preferences(self, user_id: str, user_input: str) -> Dict:
        """
        Process input from a user with preference-based customization.
        
        Args:
            user_id: Unique identifier for the user
            user_input: Input text from the user
            
        Returns:
            response: Customized system response
        """
        # Ensure user profile exists
        if user_id not in self.user_profiles:
            self.create_user_profile(user_id)
        
        # Get user preferences
        preferences = self.user_profiles[user_id].get_preferences()
        
        # Process input using core functionality
        response = self.process_input(user_id, user_input)
        
        # Adapt content based on user preferences
        if "content" in response:
            # Convert response content to a structured format for adaptation
            content_dict = {
                "content": response["content"]
            }
            
            # Add additional fields if available
            if "type" in response:
                content_dict["type"] = response["type"]
            
            # Adapt content
            adapted_content = self.content_adaptation_system.adapt_content(content_dict, preferences)
            
            # Update response with adapted content
            response["content"] = adapted_content["content"]
        
        return response
    
    def generate_explanation_with_template(self, user_id: str, concept: str, 
                                          template_type: str = "explanation", 
                                          template_name: str = None) -> Dict:
        """
        Generate an explanation using a template.
        
        Args:
            user_id: Unique identifier for the user
            concept: The concept to explain
            template_type: Type of template to use
            template_name: Name of the specific template (optional)
            
        Returns:
            explanation: The generated explanation
        """
        # Ensure user profile exists
        if user_id not in self.user_profiles:
            self.create_user_profile(user_id)
        
        # Get user preferences
        preferences = self.user_profiles[user_id].get_preferences()
        
        # Determine template name if not specified
        if not template_name:
            difficulty_level = preferences.get("difficulty_level", DifficultyLevel.INTERMEDIATE.value)
            if difficulty_level == DifficultyLevel.BEGINNER.value:
                template_name = "beginner"
            elif difficulty_level == DifficultyLevel.ADVANCED.value:
                template_name = "advanced"
            else:
                template_name = "default"
        
        # Check for custom template first
        template = self.template_system.get_custom_template(user_id, template_type, template_name)
        
        # Fall back to system template if no custom template exists
        if not template:
            template = self.template_system.get_template(template_type, template_name)
        
        # Generate explanation content
        instruction = self.pedagogical_engine.generate_instruction(
            user_id,
            concept,
            preferences.get("teaching_style"),
            preferences.get("difficulty_level")
        )
        
        # Prepare values for template
        values = {
            "concept": concept,
            "content": instruction.get("explanation", ""),
            "summary": instruction.get("summary", f"These are the key points about {concept}."),
            "next_steps": instruction.get("next_steps", "practice applying these concepts.")
        }
        
        # Apply template
        explanation = self.template_system.apply_template(template, values)
        
        # Adapt content based on user preferences
        adapted_explanation = self.content_adaptation_system.adapt_content(explanation, preferences)
        
        return adapted_explanation
    
    def create_custom_template(self, user_id: str, template_type: str, template_name: str, template: Dict) -> bool:
        """
        Create a custom template for a user.
        
        Args:
            user_id: Unique identifier for the user
            template_type: Type of template
            template_name: Name for the custom template
            template: The template content
            
        Returns:
            success: Whether the template was successfully created
        """
        try:
            self.template_system.add_custom_template(user_id, template_type, template_name, template)
            return True
        except Exception as e:
            print(f"Error creating custom template: {e}")
            return False
    
    def save_user_profile(self, user_id: str, directory: str) -> Optional[str]:
        """
        Save a user's preference profile to a file.
        
        Args:
            user_id: Unique identifier for the user
            directory: Directory to save the profile
            
        Returns:
            file_path: Path to the saved profile file, or None if failed
        """
        if user_id not in self.user_profiles:
            return None
        
        try:
            return self.user_profiles[user_id].save_profile(directory)
        except Exception as e:
            print(f"Error saving user profile: {e}")
            return None
    
    def load_user_profile(self, user_id: str, file_path: str) -> bool:
        """
        Load a user's preference profile from a file.
        
        Args:
            user_id: Unique identifier for the user
            file_path: Path to the profile file
            
        Returns:
            success: Whether the profile was successfully loaded
        """
        if user_id not in self.user_profiles:
            self.create_user_profile(user_id)
        
        return self.user_profiles[user_id].load_profile(file_path)


# ======================================================================
# Example Usage
# ======================================================================

def example_usage():
    """Example usage of the Enhanced Personal Learning Tutor GPT."""
    # Initialize the enhanced tutor
    tutor = EnhancedPersonalLearningTutorGPT()
    
    # Create a user profile
    user_id = "user_123"
    tutor.create_user_profile(user_id, {
        "teaching_style": TeachingStyle.SOCRATIC.value,
        "tone_style": ToneStyle.FRIENDLY.value,
        "difficulty_level": DifficultyLevel.BEGINNER.value,
        "learning_style": LearningStyle.VISUAL.value,
        "content_format": ContentFormat.STEP_BY_STEP.value,
        "verbosity": 0.8,
        "example_frequency": 0.9
    })
    
    # Process some sample content
    sample_content = """
    # Introduction to Machine Learning
    
    Machine Learning is a subset of artificial intelligence that focuses on developing systems that can learn from and make decisions based on data.
    
    ## Supervised Learning
    
    Supervised learning is a type of machine learning where the model is trained on labeled data. The model learns to map inputs to outputs based on example input-output pairs.
    
    ## Unsupervised Learning
    
    Unsupervised learning is a type of machine learning where the model is trained on unlabeled data. The model learns to find patterns and relationships in the data without explicit guidance.
    """
    
    content_id = tutor.process_content(
        sample_content, 
        "notes", 
        {"author": "AI Tutor", "date": "2025-04-06"}
    )
    
    print(f"Processed content with ID: {content_id}")
    
    # Generate an explanation using a template
    explanation = tutor.generate_explanation_with_template(
        user_id,
        "Machine Learning",
        "explanation",
        "beginner"
    )
    
    print("\nGenerated Explanation:")
    for key, value in explanation.items():
        print(f"\n{key.upper()}:")
        print(value)
    
    # Create a custom template
    custom_template = {
        "title": "Let's Learn About {concept}",
        "introduction": "I'm excited to teach you about {concept}!",
        "explanation": "{content}",
        "summary": "To wrap up our discussion on {concept}: {summary}",
        "next_steps": "Ready to practice? {next_steps}"
    }
    
    tutor.create_custom_template(user_id, "explanation", "enthusiastic", custom_template)
    
    # Generate an explanation using the custom template
    custom_explanation = tutor.generate_explanation_with_template(
        user_id,
        "Supervised Learning",
        "explanation",
        "enthusiastic"
    )
    
    print("\nGenerated Explanation with Custom Template:")
    for key, value in custom_explanation.items():
        print(f"\n{key.upper()}:")
        print(value)
    
    # Process user input with preferences
    response = tutor.process_input_with_preferences(
        user_id,
        "Can you explain unsupervised learning?"
    )
    
    print("\nResponse to User Input:")
    print(response["content"])
    
    # Save user profile
    profile_path = tutor.save_user_profile(user_id, "./profiles")
    print(f"\nSaved user profile to: {profile_path}")


if __name__ == "__main__":
    example_usage()
